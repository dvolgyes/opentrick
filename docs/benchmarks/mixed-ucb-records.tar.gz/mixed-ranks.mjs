import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {mixedDeal} from './scripts/self-play/mixed-deals.ts';
import {mixedReport} from './scripts/self-play/mixed-score.ts';
import {applyAction, boardStatus} from './src/bridge/engine.ts';
import {obviousPlay} from './src/bot/obvious-play.ts';
import {playPosition} from './src/bot/play-position.ts';
import {mapLegalRankClasses} from './src/bot/rank-classes.ts';
const raw=await readFile(process.argv[2]+'/mixed-ucb.jsonl','utf8');
const summary=mixedReport(raw);
function counts(){return {decisions:0, legalCards:0, rankClasses:0, multiRank:0, choseHigherEquivalent:0};}
const ranks=Object.fromEntries(['base','plain','biased'].map(name=>[name,Object.fromEntries(['opening','defense','declarer'].map(role=>[role,counts()]))]));
for(const line of raw.trim().split('\n')){
 const row=JSON.parse(line), fixture=mixedDeal(row.index,row.seed);
 for(const pair of row.pairs) for(const [room,candidateNS] of [[pair.ns,true],[pair.ew,false]]){
  let board=fixture;
  for(const card of room.cards){
   const actor=boardStatus(board).actor; assert(actor);
   const pos=playPosition(board,actor);
   if(obviousPlay(pos)===undefined){
    const name=('NS'.includes(actor)===candidateNS)?pair.candidate:pair.control;
    const role=board.cards.length===0?'opening':actor===row.contract.declarer?'declarer':'defense';
    const v=ranks[name][role];
    const keys=new Map(mapLegalRankClasses(pos,(c,key)=>[c,key]));
    const classes=new Set(keys.values()).size, n=pos.legal.length;
    assert(keys.has(card) && classes>1 && classes<=n);
    const strength=c=>'23456789TJQKA'.indexOf(c[1]);
    v.decisions++; v.legalCards+=n; v.rankClasses+=classes; v.multiRank+=Number(classes<n);
    v.choseHigherEquivalent+=Number(pos.legal.some(c=>keys.get(c)===keys.get(card) && strength(c)<strength(card)));
   }
   const next=applyAction(board,actor,{type:'play',card}); assert(next.ok); board=next.board;
  }
 }
}
for(const [name,roles] of Object.entries(ranks)) for(const [role,stat] of Object.entries(roles)) assert.equal(stat.decisions,summary.work[name][role]);
console.log(JSON.stringify(ranks,null,2));
