import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {makeBoard, playTable, random} from './scripts/self-play/arena.ts';
import {mixedDeal} from './scripts/self-play/mixed-deals.ts';
import {DdsSolver} from './src/bot/dds-solver.ts';
import {playPosition} from './src/bot/play-position.ts';
import {obviousPlay} from './src/bot/obvious-play.ts';
import {analyzeLocalPlay} from './src/bot/play-engine.ts';
import {createHandSampler} from './src/bot/play-sampling.ts';
import {boardStatus, parseBoard, scoreBoard} from './src/bridge/engine.ts';
import {scoreDifferenceToImps} from './src/bridge/scoring.ts';
const mode=process.argv[2];
if(mode==='play'){
 const [start,count]=process.argv.slice(3).map(Number);
 assert(Number.isInteger(start)&&Number.isInteger(count)&&start>=0&&count>0&&start+count<=80);
 const warmBoard=makeBoard(42,1,42);
 const pos=playPosition(warmBoard,boardStatus(warmBoard).actor);
 const sample=createHandSampler(pos.view)(random(43));
 async function incumbent(){
  const solver=await DdsSolver.create();solver.solve(sample,pos.contract.strain,pos.current);
  return (p,rng)=>obviousPlay(p)??analyzeLocalPlay(p,solver,{timeMs:100,random:rng}).card;
 }
 for(let i=start;i<start+count;i++){
  const b=mixedDeal(i,1720000000+i);
  const distribution=createHash('sha256').update(['N','E','S','W'].map(s=>[...b.deal[s]].sort().join('')).join('|')).digest('hex');
  const table=playTable(b,await incumbent(),await incumbent(),1721000000+i);
  console.log(JSON.stringify({index:i,distribution,table}));
 }
}else{
 assert.equal(mode,'score');const dir=process.argv[3];
 const load=async name=>(await readFile(dir+'/'+name,'utf8')).trimEnd().split('\n').map(JSON.parse);
 const [rows,references]=await Promise.all([load('mixed-ucb.jsonl'),load('references.jsonl')]);
 assert.equal(rows.length,80);assert.equal(references.length,80);
 const arm=()=>({tricks:0,imps:0,wins:0,losses:0,ties:0,makeSwings:0});
 const report={plain:{declaring:arm(),defending:arm()},biased:{declaring:arm(),defending:arm()}};
 for(const [i,row] of rows.entries()){
  const r=references[i];assert.equal(row.index,i);assert.equal(r.index,i);assert.equal(r.distribution,row.distribution);
  const b=mixedDeal(i,row.seed),completed=parseBoard({...b,cards:r.table.cards});assert(completed);const score=scoreBoard(completed);
  assert.equal(r.table.cards.length,52);assert.equal(r.table.declarerTricks,score.declarerTricks);assert.equal(r.table.scoreNS,score.scoreNS);
  const target=row.contract.level+6,declaresNS='NS'.includes(row.contract.declarer);
  for(const pair of row.pairs.filter(p=>p.control==='base')){
   for(const [side,t] of [['ns',pair.ns],['ew',pair.ew]]){
    const actingNS=side==='ns',declaring=actingNS===declaresNS,sign=declaring?1:-1;
    const a=report[pair.candidate][declaring?'declaring':'defending'];
    const imp=scoreDifferenceToImps((actingNS?1:-1)*(t.scoreNS-r.table.scoreNS));
    a.tricks+=sign*(t.declarerTricks-r.table.declarerTricks);a.imps+=imp;a.wins+=Number(imp>0);a.losses+=Number(imp<0);a.ties+=Number(imp===0);
    a.makeSwings+=sign*(Number(t.declarerTricks>=target)-Number(r.table.declarerTricks>=target));
   }
  }
 }
 for(const roles of Object.values(report))for(const a of Object.values(roles))assert.equal(a.wins+a.losses+a.ties,80);
 console.log(JSON.stringify(report,null,2));
}
