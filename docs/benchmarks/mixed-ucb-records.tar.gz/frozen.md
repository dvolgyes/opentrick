# Whole-board information-set UCB in duplicate bridge

## Frozen question

Does a general information-set UCB player beat the incumbent at a common short clock when each plays both declarer and defense from the opening lead through trick thirteen?
The earlier 3NT hold-up experiment cannot answer this question: it changed only one card choice in a narrow population.
This study neither trains nor evaluates a bidder.
No candidate receives the complete deal, the fixture's HCP or shape filter, or an auction likelihood.

## Contract matrix and paired play

Use 80 fresh boards, index `i=0…79`, seed `1720000000+i` for dealing and `1721000000+i` for search.
For each seed use the first qualifying arena shuffle, with no DDS selection of deals.
The board number is `i+1`; the standard dealer and vulnerability rotate, and the dealer declares.
The strain cycles through clubs, diamonds, hearts, spades, and notrump in that order, so each has 16 distinct deals.
The profile is `floor(i/5)`:

| Profiles per strain | Assigned contracts | Partnership HCP |
| --- | --- | --- |
| 0–7 | Levels 1, 2, 2, 1, 3, 2, 2, 2; use 2NT rather than 3NT in profile 4; double profile 6 and redouble profile 7 | 18–24 |
| 8–13 | 5 of a minor, 4 of a major, or 3NT, undoubled | 27–32 for minors, 25–31 otherwise |
| 14 | Small slam in the assigned strain | 30–34 |
| 15 | Grand slam in the assigned strain | 34–37 |

Suit-contract hands require at least eight combined trumps and at least as many trumps in declarer's hand as dummy's.
At notrump declarer must hold shape 4333, 4432, or 5332 and at least as many HCP as dummy.
This fixed coverage matrix includes deliberately uncommon contracts, especially redoubles and grand slams; it does not estimate the frequency-weighted performance of a tournament field.

Compare Plain against Base, Biased against Base, and Biased against Plain directly on each board.
For each comparison play two rooms: candidate North–South versus control East–West, then exchange the policies on the same deal and contract.
Alternate which room runs first by board parity and rotate comparison order by index modulo three.
Keep all 52 plays per room, the actual tricks, and the duplicate score; do not reuse timed decisions across rooms.
Use the arena's per-ply, per-controller stream, the common `obviousPlay` shortcut, and a uniform 100 ms search allowance at every other decision in each arm.
Base uses the current local card engine at `2de47f8466`.
Use warmed DDS instances, no sample cap for the timed match, and record overshoots of any uninterruptible native call.
This is a short-clock screen, not a five-second strength claim.

## Policy and information boundary

At every non-obvious move both trees draw hypothetical layouts from the acting controller's visible hand, exposed dummy when permitted, and public play history including voids.
Use one separate initial DDS layout to provide every legal root card with one estimated return in IMPs relative to the contract just made, from the acting partnership's perspective.
Sample a new layout for each subsequent tree simulation.
Tree decisions belong to the current controller only: declarer controls declarer and dummy; a defender does not control partner's hand.
Public continuations branch on actual card identities; after an opening lead also branch on the newly exposed dummy, independent of the order in which its cards were sampled.
Never use the actual concealed deal to select a card.

Within each simulation, complete the current trick and the following trick, or stop when no cards remain.
The native leaf scores the remaining tricks for the side on lead; convert to declarer tricks and signed duplicate IMP utility with the actual strain, level, doubling and vulnerability.
Other players are modeled by a fallible policy restricted to the acting hand and the public trick.
It leads from its longest suit (tie order S/H/D/C), using the top of a touching sequence headed by ten or higher, otherwise fourth-highest or low from a short suit.
It plays low if partner is winning, otherwise its cheapest winner, including a ruff or overruff, or low if there is no winner.
This model is intentionally the same in both trees.

Try unvisited actions first, ordered by the bootstrap estimates at the root and by low rank then S/H/D/C elsewhere.
Use the empirical mean with the root bootstrap observation plus the exploration term `6*sqrt(log(1+N)/n)` for visited actions, with real node visits `N` and real action visits `n`.
Only Biased also gives the model's suggested card `2/(1+n)` at each tree-controlled decision.
No heuristic forbids a legal card or merges later public histories.
At the deadline, choose the most visited root card, breaking ties by mean then public order; if there was not time to explore every card, choose the highest available mean, including the bootstrap.
An initial native call that exhausts the clock yields a bootstrap-only decision and must be counted as such.

## Scoring, stopping, and limits

For each direct match convert `candidate-NS room NS score − candidate-EW room NS score` once to IMPs, from the candidate's perspective.
Report W/L/T, mean and total IMPs across all 80 scheduled boards, and descriptive totals per strain and contract group.
The independent unit is the deal, not a card, a simulation or a room.
A subgroup is not a promotion test.
Use a common sequence of 20,000 bootstrap samples from `arena.random(0x42524944)`; for each sample draw 16 boards with replacement within each of the five strains.
Use the one-sided Bonferroni lower order statistic at zero-based index 333 for the three direct comparisons and the exact one-sided sign test on non-ties.
A qualifying comparison needs at least 20 non-ties, a sign probability below `0.05/3`, and a bootstrap lower bound strictly greater than +0.10 IMP per board.
Prefer Biased only if it qualifies against Base and Plain; otherwise Plain may qualify against Base.
If neither qualifies, keep the incumbent, report every contrast, and do not reinterpret a favorable subgroup as a win.
A passing screen nominates a policy for an independent normal-clock confirmation, not live adoption.
A missing, duplicate, off-schedule, or illegally replayed board blocks the decision; do not replace it or stop early based on its result.
