import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

assert.equal(process.argv.length, 3, 'usage: node --import tsx --input-type=module - OUT');
const out = process.argv[2];
const project = name => pathToFileURL(join(process.cwd(), 'scripts/self-play', `${name}.ts`)).href;
const [{ mixedDeal }, { random }] = await Promise.all(
  ['mixed-deals', 'arena'].map(name => import(project(name))),
);
const seats = ['N', 'E', 'S', 'W'];
const strains = ['C', 'D', 'H', 'S', 'NT'];
const ranks = '23456789TJQKA';
const deck = /^[CDHS][2-9TJQKA]$/;
const vulCycle = ['none', 'NS', 'EW', 'both', 'NS', 'EW', 'both', 'none',
  'EW', 'both', 'none', 'NS', 'both', 'none', 'NS', 'EW'];
const comparisons = ['plain-base', 'biased-base', 'biased-plain'];
const matrix = i => {
  const strain = strains[i % 5];
  const p = Math.floor(i / 5);
  return {
    level: [1, 2, 2, 1, strain === 'NT' ? 2 : 3, 2, 2, 2][p] ??
      (p === 15 ? 7 : p === 14 ? 6 : strain === 'NT' ? 3 : 'CD'.includes(strain) ? 5 : 4),
    strain, declarer: seats[i % 4], doubling: p === 6 ? 'X' : p === 7 ? 'XX' : '',
  };
};
const fingerprint = deal => createHash('sha256').update(
  seats.map(seat => [...deal[seat]].sort().join('')).join('|'),
).digest('hex');
const sameKeys = (value, keys) => {
  assert(value && typeof value === 'object' && !Array.isArray(value), 'expected object');
  assert.deepEqual(Object.keys(value).sort(), [...keys].sort(), 'unexpected record fields');
};

function duplicateNS(contract, vulnerable, tricks) {
  const { level, strain, declarer, doubling } = contract;
  const made = tricks - (6 + level);
  const minor = 'CD'.includes(strain);
  const factor = doubling === 'XX' ? 4 : doubling === 'X' ? 2 : 1;
  const ns = declarer === 'N' || declarer === 'S';
  const vul = vulnerable === 'both' || vulnerable === (ns ? 'NS' : 'EW');
  let score;
  if (made < 0) {
    const down = -made;
    if (factor === 1) score = -down * (vul ? 100 : 50);
    else {
      const doubledPenalty = vul ? 200 + (down - 1) * 300
        : 100 + Math.min(2, down - 1) * 200 + Math.max(0, down - 3) * 300;
      score = -doubledPenalty * (factor / 2);
    }
  } else {
    const trickPoints = (minor ? 20 : 30) * level + (strain === 'NT' ? 10 : 0);
    const contracted = trickPoints * factor;
    const overtrick = factor === 1 ? (minor ? 20 : 30) : (vul ? 100 : 50) * factor;
    score = contracted + made * overtrick + (contracted < 100 ? 50 : vul ? 500 : 300);
    score += factor === 1 ? 0 : factor * 25;
    if (level === 6) score += vul ? 750 : 500;
    if (level === 7) score += vul ? 1500 : 1000;
  }
  return ns ? score : -score;
}

const freshTrumps = () => ({ tables: 0, tricks: 0, trumpLedTricks: 0,
  ruffCards: 0, overruffCards: 0, wonByRuff: 0, wonByOverruff: 0 });
const trumpEvidence = Object.fromEntries(strains.map(s => [s, freshTrumps()]));
const roomCoverage = { tables: 0, plays: 0 };

function replay(table, dealt, contract, vulnerability, coverage = roomCoverage, evidence = trumpEvidence[contract.strain]) {
  sameKeys(table, ['cards', 'declarerTricks', 'scoreNS']);
  assert(Array.isArray(table.cards) && table.cards.length === 52, 'expected all 52 cards');
  const hands = seats.map(seat => new Set(dealt[seat]));
  const seen = new Set();
  const declarer = seats.indexOf(contract.declarer);
  const trump = contract.strain === 'NT' ? null : contract.strain;
  let leader = (declarer + 1) % 4;
  let tricks = 0;
  for (let t = 0; t < 13; t++) {
    let led, winner, best = -1, winningRuff = false, winningOverruff = false;
    for (let offset = 0; offset < 4; offset++) {
      const turn = (leader + offset) % 4;
      const controller = turn === (declarer + 2) % 4 ? declarer : turn;
      const hand = hands[turn];
      const card = table.cards[t * 4 + offset];
      const where = `trick ${t + 1}, hand ${seats[turn]}, controller ${seats[controller]}`;
      assert(typeof card === 'string' && card.length === 2 && deck.test(card), `bad card at ${where}`);
      assert(hand.has(card) && !seen.has(card), `wrong hand or repeated card ${card} at ${where}`);
      const [suit, rank] = card;
      if (offset === 0) {
        led = suit;
        evidence.trumpLedTricks += Number(suit === trump);
      } else if (suit !== led) {
        assert(![...hand].some(held => held[0] === led), `revoke with ${card} at ${where}`);
      }
      hand.delete(card);
      seen.add(card);
      const power = suit === trump ? 13 + ranks.indexOf(rank)
        : suit === led ? ranks.indexOf(rank) : -1;
      const ruff = suit === trump && led !== trump;
      const overruff = ruff && best >= 13 && power > best;
      evidence.ruffCards += Number(ruff);
      evidence.overruffCards += Number(overruff);
      if (power > best) {
        best = power;
        winner = turn;
        winningRuff = ruff;
        winningOverruff = overruff;
      }
    }
    assert(winner !== undefined);
    leader = winner;
    tricks += Number(winner % 2 === declarer % 2);
    evidence.wonByRuff += Number(winningRuff);
    evidence.wonByOverruff += Number(winningOverruff);
  }
  assert.equal(seen.size, 52);
  assert(hands.every(hand => hand.size === 0));
  assert.equal(table.declarerTricks, tricks, 'declarer tricks');
  const score = duplicateNS(contract, vulnerability, tricks);
  assert.equal(table.scoreNS, score, 'NS duplicate score');
  evidence.tables++;
  evidence.tricks += 13;
  coverage.tables++;
  coverage.plays += seen.size;
  return score;
}

const impMinimums = [20, 50, 90, 130, 170, 220, 270, 320, 370, 430, 500, 600,
  750, 900, 1100, 1300, 1500, 1750, 2000, 2250, 2500, 3000, 3500, 4000];
function imps(delta) {
  const magnitude = impMinimums.filter(min => min <= Math.abs(delta)).length;
  return magnitude === 0 ? 0 : Math.sign(delta) * magnitude;
}
function exactTail(wins, losses) {
  const n = BigInt(wins + losses);
  let combinations = 1n;
  let favorable = 0n;
  for (let k = 0n; k <= n; k++) {
    if (k >= wins) favorable += combinations;
    combinations = combinations * (n - k) / (k + 1n);
  }
  return Number(favorable) / 2 ** Number(n);
}

const workFields = ['decisions', 'obvious', 'searches', 'opening', 'defense', 'declarer',
  'elapsedMs', 'peakMs', 'ddsCalls', 'simulations', 'rootCoverage', 'rootLegal',
  'incomplete', 'bootstrapOnly', 'revisits'];
const work = Object.fromEntries(['base', 'plain', 'biased'].map(name =>
  [name, Object.fromEntries(workFields.map(field => [field, 0]))]));
function accumulateWork(name, w) {
  sameKeys(w, workFields);
  for (const field of workFields) {
    const v = w[field];
    assert(Number.isFinite(v) && v >= 0, `invalid ${name}.${field}`);
    if (!['elapsedMs', 'peakMs'].includes(field)) assert(Number.isSafeInteger(v));
    if (field === 'peakMs') work[name][field] = Math.max(work[name][field], v);
    else work[name][field] += v;
  }
  assert.equal(w.decisions, 52);
  assert.equal(w.obvious + w.searches, w.decisions);
  assert.equal(w.opening + w.defense + w.declarer, w.searches);
  assert(w.rootCoverage <= w.rootLegal && w.bootstrapOnly <= w.incomplete && w.incomplete <= w.searches);
  assert(w.peakMs <= w.elapsedMs);
}

const [raw, summaryText] = await Promise.all(['mixed-ucb.jsonl', 'summary.json'].map(name =>
  readFile(join(out, name), 'utf8'),
));
const lines = raw.replace(/\r?\n$/, '').split(/\r?\n/);
assert.equal(lines.length, 80, 'expected one canonical row per scheduled board');
const values = Object.fromEntries(comparisons.map(vs => [vs, []]));
const fingerprints = new Set();
const historicalOrder = new Set();
for (const [i, line] of lines.entries()) {
  try {
    const row = JSON.parse(line);
    sameKeys(row, ['index', 'seed', 'number', 'contract', 'vulnerability', 'distribution', 'pairs']);
    const seed = 1_720_000_000 + i;
    const contract = matrix(i);
    const vulnerability = vulCycle[i % 16];
    assert.equal(row.index, i);
    assert.equal(row.seed, seed);
    assert.equal(row.number, i + 1);
    assert.deepEqual(row.contract, contract);
    assert.equal(row.vulnerability, vulnerability);
    const board = mixedDeal(i, seed);
    assert.equal(board.number, i + 1);
    assert.equal(board.dealer, contract.declarer);
    assert.equal(board.vulnerability, vulnerability);
    assert.equal(board.cards.length, 0);
    const dealt = seats.flatMap(seat => {
      assert.equal(board.deal[seat].length, 13);
      return board.deal[seat];
    });
    assert(dealt.every(card => typeof card === 'string' && card.length === 2 && deck.test(card)));
    assert.equal(new Set(dealt).size, 52, 'regenerated deal is not a full deck');
    const id = fingerprint(board.deal);
    assert.equal(row.distribution, id);
    assert(!fingerprints.has(id), 'repeated scheduled deal');
    fingerprints.add(id);
    historicalOrder.add(createHash('sha256').update(seats.map(s => board.deal[s].join('')).join('|')).digest('hex'));
    assert(Array.isArray(row.pairs) && row.pairs.length === comparisons.length);
    for (const [j, pair] of row.pairs.entries()) {
      const vs = comparisons[(i + j) % comparisons.length];
      const [candidate, control] = vs.split('-');
      sameKeys(pair, ['candidate', 'control', 'ns', 'ew', 'imps', 'work']);
      assert.equal(pair.candidate, candidate);
      assert.equal(pair.control, control);
      const scores = ['ns', 'ew'].map(side => {
        try {
          return replay(pair[side], board.deal, contract, vulnerability);
        } catch (cause) {
          throw new Error(`${vs} candidate-${side.toUpperCase()} room`, { cause });
        }
      });
      const imp = imps(scores[0] - scores[1]);
      assert.equal(pair.imps, imp, `${vs} direct IMPs`);
      values[vs].push(imp);
      sameKeys(pair.work, [candidate, control]);
      for (const name of [candidate, control]) accumulateWork(name, pair.work[name]);
    }
  } catch (cause) {
    throw new Error(`Scheduled board ${i + 1}`, { cause });
  }
}

function statistics(returns) {
  assert.equal(returns.length, 80);
  const sum = xs => xs.reduce((a, b) => a + b, 0);
  const wins = returns.filter(x => x > 0).length;
  const losses = returns.filter(x => x < 0).length;
  const total = sum(returns);
  const strata = strains.map((_, s) => returns.filter((_, i) => i % 5 === s));
  const rng = random(0x42524944);
  const sums = Array.from({ length: 20_000 }, () => sum(strata.map(stratum => {
    let subtotal = 0;
    for (const _ of stratum) subtotal += stratum[Math.floor(rng() * stratum.length)];
    return subtotal;
  }))).sort((a, b) => a - b);
  const lower = sums[333] / returns.length;
  const signP = exactTail(wins, losses);
  return { total, mean: total / returns.length, wins, losses, ties: returns.length - wins - losses,
    lower, signP, qualifies: wins + losses >= 20 && signP < 0.05 / 3 && lower > 0.10,
    strain: Object.fromEntries(strains.map((s, i) => [s, sum(strata[i])])),
    group: { low: sum(returns.slice(0, 40)), game: sum(returns.slice(40, 70)),
      small: sum(returns.slice(70, 75)), grand: sum(returns.slice(75)) },
  };
}
const results = Object.fromEntries(comparisons.map(vs => [vs, statistics(values[vs])]));
const nominated = results['biased-base'].qualifies && results['biased-plain'].qualifies ? 'biased'
  : results['plain-base'].qualifies ? 'plain' : null;
const report = { boards: fingerprints.size, ...roomCoverage, results, work, nominated };
const recorded = JSON.parse(summaryText);
for (const vs of comparisons) {
  const p = recorded?.results?.[vs]?.signP;
  assert(Number.isFinite(p) && p > 0 && p <= 1, `${vs}: invalid recorded sign p`);
  assert(Math.abs(p - results[vs].signP) <= 16 * Number.EPSILON * results[vs].signP,
    `${vs}: recorded sign p differs from exact binomial tail`);
  recorded.results[vs].signP = results[vs].signP;
}
assert.deepEqual(recorded, report, 'recorded summary differs from independent replay');

const overlap = {};
assert.equal(historicalOrder.size, fingerprints.size);
for (const [name, file, count] of [
  ['historicalHoldUp', 'historical-3nt.sha256', 256],
  ['historicalHoldUpPilot', 'historical-pilot.sha256', 64],
]) {
  const past = new Set((await readFile(join(out, file), 'utf8')).trim().split('\n'));
  assert.equal(past.size, count);
  assert([...past].every(id => /^[0-9a-f]{64}$/.test(id)));
  const matches = [...past].filter(id => historicalOrder.has(id)).length;
  assert.equal(matches, 0, `mixed deals overlap ${name}`);
  overlap[name] = { archived: past.size, matches };
}
const referenceCoverage = { tables: 0, plays: 0 };
const references = (await readFile(join(out, 'references.jsonl'), 'utf8')).trimEnd().split('\n').map(JSON.parse);
assert.equal(references.length, 80);
const emptyRole = () => ({ tricks: 0, imps: 0, wins: 0, losses: 0, ties: 0, makeSwings: 0 });
const roles = Object.fromEntries(['plain', 'biased'].map(n => [n, { declaring: emptyRole(), defending: emptyRole() }]));
for (const [i, ref] of references.entries()) {
  const row = JSON.parse(lines[i]);
  const contract = matrix(i);
  const board = mixedDeal(i, row.seed);
  assert.equal(ref.index, i);
  assert.equal(ref.distribution, row.distribution);
  const scoreNS = replay(ref.table, board.deal, contract, row.vulnerability, referenceCoverage, freshTrumps());
  const sign = seats.indexOf(contract.declarer) % 2 ? -1 : 1;
  for (const pair of row.pairs.filter(p => p.control === 'base')) {
    const declaring = sign > 0 ? pair.ns : pair.ew;
    const defending = sign > 0 ? pair.ew : pair.ns;
    for (const [name, table, direction] of [['declaring', declaring, 1], ['defending', defending, -1]]) {
      const v = roles[pair.candidate][name];
      const margin = imps(direction * sign * (table.scoreNS - scoreNS));
      const target = 6 + contract.level;
      v.imps += margin;
      v.wins += Number(margin > 0);
      v.losses += Number(margin < 0);
      v.ties += Number(margin === 0);
      v.tricks += direction * (table.declarerTricks - ref.table.declarerTricks);
      v.makeSwings += direction * (Number(table.declarerTricks >= target) - Number(ref.table.declarerTricks >= target));
    }
  }
}
assert.deepEqual(roles, JSON.parse(await readFile(join(out, 'roles.json'), 'utf8')));
console.log(JSON.stringify({ ...report, trumpEvidence, referenceCoverage, roles, overlap, limits: [
  'Replay checks card ownership and the implied controller; raw rows do not log actual controller calls, policy execution, RNG streams, or concealed information access.',
  'Work counters are checked for consistency and reconciled with the summary, not measured independently.',
  'Overlap is exact by assigned-seat deal fingerprint, not modulo seat or suit permutations.',
  'The frozen short-clock sample is not tournament-frequency weighted or a normal-clock strength confirmation.',
] }, null, 2));
