# Information-set UCB for the 3NT hold-up

## Frozen comparison

This experiment tests declarer's card play, not bidding, on 256 fresh balanced-opener 3NT games.
The 64 development deals suggested the ace control; none may enter the holdout.
The base engine is `c3dc025b9c`.
Use Node 22, the locked dependencies, and one logical CPU per worker without assigning two study workers to the same physical core.
Do not inspect partial results to adjust the policy, population, budget, or stopping point.
A failed or incomplete board blocks the evidence decision; do not replace it with another seed.

For index `i = 0…255`, start an independent arena PRNG at `1680000000+i` and keep the first shuffled deal with 15–17 HCP and shape 4333, 4432 or 5332 in North and 25–27 combined HCP in North and South.
Use board number `1+4*(i%4)` to keep North the dealer and cycle vulnerability.
Use the fixed notrump auction from `scripts/benchmark-notrump.ts`: North opens 1NT and declares 3NT, with an invitation for a responder below 10 HCP.
No arm receives auction weights, the generating HCP constraints, or the actual concealed holdings.
Check that all accepted deal fingerprints are unique and disjoint from the pilot, whose deal generator started at `46738000`.

Use incumbent play to reach the first eligible fourth-hand decision in the first three tricks, by declarer or dummy.
The acting hand must follow the led suit; its ace must be its only legal card that wins the trick for the partnership, and it must also be able to lose it.
Only this decision can differ between arms.
Use the same seeded eight-layout incumbent for all other decisions, skipping obvious plays; do not truncate the fixed workload silently.
Use the arena per-ply, per-actor stream derived from `1681000000+i`.
For the actual table, complete each distinct chosen card once and reuse its real score in arms that chose the same card.
If no fork occurs, finish the table once and count its score in all four arms.

| Arm | Policy at the eligible decision |
| --- | --- |
| Base | Production local search for 5,000 ms without a sample cap |
| Take | Play the ace immediately |
| Plain | Information-set UCB for 5,000 ms |
| Biased | The same UCB search with a fading hold-up bonus |

Use independent warmed solver instances for the three timed choices and rotate their execution order through the six permutations by board index.
Start timed arms with the same random seed, not shared mutable RNG state.
The deadline prevents starting a new simulation; a synchronous solve already in progress can finish after it.
Record actual elapsed time, not only the nominal limit.
The ace control gets the same maximum allowance but needs no search.

### Search under test

Sample each layout from the incumbent hand sampler constrained by the public history and the two visible hands.
Each simulation completes the current trick and searches the following trick.
Use UCB at each declarer or dummy decision before the cutoff, including moves after defenders reveal a card.
Only declarer and dummy make tree decisions; their remaining hands are fixed by the root and public sequence.
Each such node identifies a continuation by the public card sequence from this root, never by concealed card ownership.
Every legal card stays eligible, including a higher spot that ducks; try unvisited cards first, low rank first, breaking suit ties in S/H/D/C order.
Among visited choices maximize mean declarer IMP utility plus `6*sqrt(log(parent visits)/child visits)`.
The biased arm adds `2/(1+child visits)` only to the lowest duck at the root, only with 3–6 led-suit cards remaining across both visible hands, no visible king or queen in that suit in either hand, and both defenders following suit on the trick.
This is a hypothesis about a lone stopper, not a claim that ducking is correct.
Select the root card with the most visits, then the higher mean, then the same card order.

Defenders do not select actions from the tree: recompute their policy for each simulation from the acting defender's own sampled hand and public play, then branch the declarer tree on the card it observes.
On lead they choose their longest suit, leading the top of a touching honor sequence (ten or higher), otherwise fourth-highest or low from fewer than four.
When following, play the cheapest winner if partner is not winning, otherwise the lowest legal card; if there is no winner, play low.
At the horizon use native double-dummy tricks for the side on turn and convert to final declarer tricks, duplicate score, and declarer's signed IMP utility relative to making the contract exactly.
The leaf still assumes perfect information beyond the cutoff, and the simulated defender is an approximation of the actual incumbent defender.
An apparent gain over Base cannot be attributed solely to UCB; Biased minus Plain isolates the incremental policy change with timed-search variability.

### Acceptance and release boundary

Report all six paired contrasts: Take−Base, Plain−Base, Plain−Take, Biased−Base, Biased−Take, and Biased−Plain.
Convert the difference of the two actual North–South scores to IMPs **once per board**, then average across all 256 deals, including identity ties.
Report net IMPs, wins/losses/ties, make differences, work, and elapsed time.
For each contrast require at least 12 nonzero board IMP differences, a one-sided exact sign-test probability below `0.05/6`, and a one-sided Bonferroni board-bootstrap lower bound strictly above `+0.05` IMP per scheduled board.
Use 20,000 ordinary paired board bootstrap replicates, sharing indices from `arena.random(0x484f4c44)` across contrasts; take zero-based sorted index 166.
Prefer Biased only if it passes against Base, Take, and Plain; otherwise prefer Plain only if it passes against Base and Take; otherwise prefer Take only if it passes against Base.
If nothing qualifies, leave the production engine unchanged.
A qualifying result with eight-layout continuations is specific to that continuation policy; before changing the live default, require the same superiority contrasts to pass on independent deals with normal timed continuations.
Primary inference is restricted to this fixed 3NT population and decision; neither a negative result nor a positive one settles MCTS elsewhere in bridge.
